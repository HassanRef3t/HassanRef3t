<!-- Visitor Badge -->
<img align="right" src="https://visitor-badge.laobi.icu/badge?page_id=HassanRef3t.HassanRef3t">

<!-- Typing Title -->
<h1 align="center">
  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.herokuapp.com/?lines=Hello,+There!+👋;This+is+Hassan+Refaat....;Nice+to+meet+you!&center=true&size=30">
  </a>
</h1>

<!-- Social Links -->
<h5 align="center">
  <code><a href="https://www.linkedin.com/in/YOUR-LINKEDIN" title="LinkedIn Profile"><img width="22" src="images/linkedin.svg"> LinkedIn</a></code>
  <code><a href="https://www.hackerrank.com/YOUR-HACKERRANK" title="HackerRank Profile"><img width="22" src="images/hackerrank.png"> HackerRank</a></code>
  <code><a href="https://stackoverflow.com/users/YOUR-ID" title="Stack Overflow Profile"><img width="22" src="images/stackoverflow.svg"> Stack Overflow</a></code>
  <code><a href="https://www.instagram.com/YOUR-INSTAGRAM" title="Instagram Profile"><img width="22" src="images/instagram.svg"> Instagram</a></code>
</h5>

<hr>

<!-- Languages & Tools -->
<h2 align="center">🔥 Languages & Frameworks & Tools & Abilities 🔥</h2>
<br>
<p align="center">
  <code><img title="C++" height="25" src="images/cpp.png"></code>
  <code><img title="C#" height="25" src="images/cSharp.png"></code>
  <code><img title="Kotlin" height="25" src="images/Kotlin.png"></code>
  <code><img title="Node-js" height="25" src="images/Node-js.png"></code>
  <code><img title="JQuery" height="25" src="images/JQuery.png"></code>
  <code><img title="Java" height="25" src="images/java-original.png"></code>
  <code><img title="JSON" height="25" src="images/JSON.png"></code>
</p>
